package com.example.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn1= findViewById<Button>(R.id.btn1)
        var btn2 = findViewById<Button>(R.id.btn2)
        var btn3 = findViewById<Button>(R.id.btn3)
        var btn4 = findViewById<Button>(R.id.btn4)
        var btn5 = findViewById<Button>(R.id.btn5)
        var btn6 = findViewById<Button>(R.id.btn6)
        var btn7 = findViewById<Button>(R.id.btn7)
        var btn8 = findViewById<Button>(R.id.btn8)
        var btn9 = findViewById<Button>(R.id.btn9)
        var displayText = findViewById<TextView>(R.id.displayText)
        var playbtn = findViewById<Button>(R.id.playbtn)
        var game = arrayOf<String>("1","2","3","4","5","6","7","8","9")
        var count:Int=0
        fun winGame() {
            if (
                (game[0] == game[1] && game[1] == game[2]) ||
                (game[3] == game[4] && game[4] == game[5]) ||
                (game[6] == game[7] && game[7] == game[8]) ||
                (game[0] == game[3] && game[3] == game[6]) ||
                (game[1] == game[4] && game[4] == game[7]) ||
                (game[2] == game[5] && game[5] == game[8]) ||
                (game[0] == game[4] && game[4] == game[8]) ||
                (game[2] == game[4] && game[4] == game[6])
            ) {
                if (count % 2 == 0) {
                    displayText.text = "Player2 wins"
                } else{
                    displayText.text = "Player1 wins"
                }
            }
            else if (count == 9){
                displayText.text  = "Draw"
            }
        }
        fun playGame() {


            btn1.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn1.text = "X"
                    game[0] = "X"
                } else {
                    btn1.text = "O"
                    game[0] = "O"
                }
                winGame()
            }

            btn2.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn2.text = "X"
                    game[1] = "X"
                } else {
                    btn2.text = "O"
                    game[1] = "O"
                }
                winGame()

            }

            btn3.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn3.text = "X"
                    game[2] = "X"
                } else {
                    btn3.text = "O"
                    game[2] = "O"
                }
                winGame()

            }

            btn4.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn4.text = "X"
                    game[3] = "X"
                } else {
                    btn4.text = "O"
                    game[3] = "O"
                }
                winGame()

            }

            btn5.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn5.text = "X"
                    game[4] = "X"
                } else {
                    btn5.text = "O"
                    game[4] = "O"
                }
                winGame()

            }

            btn6.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn6.text = "X"
                    game[5] = "X"
                    winGame()
                } else {
                    btn6.text = "O"
                    game[5] = "O"
                }
                winGame()

            }

            btn7.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn7.text = "X"
                    game[6] = "X"
                } else {
                    btn7.text = "O"
                    game[6] = "O"
                }
                winGame()

            }

            btn8.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn8.text = "X"
                    game[7] = "X"
                } else {
                    btn8.text = "O"
                    game[7] = "O"
                }
                winGame()

            }

            btn9.setOnClickListener {
                count++
                if (count % 2 != 0) {
                    btn9.text = "X"
                    game[8] = "X"
                } else {
                    btn9.text = "O"
                    game[8] = "O"
                }
                winGame()

            }
        }
        playGame()
        playbtn.setOnClickListener {
            btn1.text= ""
            btn2.text= ""
            btn3.text= ""
            btn4.text= ""
            btn5.text= ""
            btn6.text= ""
            btn7.text= ""
            btn8.text= ""
            btn9.text= ""
            displayText.text = ""
            game = arrayOf<String>("1","2","3","4","5","6","7","8","9")
            count = 0
            playGame()
        }

    }
}